def func(number):
    print(number)
    return number


