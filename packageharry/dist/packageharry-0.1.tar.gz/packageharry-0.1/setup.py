from setuptools import setup, version
setup(name="packageharry",
version="0.1",
description="desc",
author="aaa",
packages=['packageharry'],
install_requires=[])

